#define _CRT_SECURE_NO_WARNINGS   1
//#include"String.h"
//
//template<class T>
//String<T>::String()
//{
//	str[0] = '\0';
//	length = 0;
//}
//
//template<class T>
//String<T>::String(string _s)
//{
//	
//}
//template<class T>
//String<T>::~String()
//{
//
//}
//
//template<class T>
//string String<T>::StrReplace(string s1,string s2, string s3,int pos)
//{
//	string s4;
//	string s5;
//	string s6;
//	for (int j = 0; j < strlen(s3); j++)
//	{
//		s5[j] = s3[j];
//	}
//	for (int i = 0; i < pos; i++)
//	{
//		s4[i] = s1[i];
//	}
//	s4 += s5;
//	for (int k = pos + strlen(s2); k < strlen(s1); k++)
//	{
//		s6[k] = s2[k];
//	}
//	s4 += s6;
//	return s4;
//
//}