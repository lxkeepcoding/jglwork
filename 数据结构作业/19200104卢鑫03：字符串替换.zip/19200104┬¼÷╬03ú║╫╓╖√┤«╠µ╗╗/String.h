//#ifndef STRING_H
//#define STRING_H
//
//#include<string>
//#include<iostream>
//using namespace std;
//
//template<class T>
//class String
//{
//	T s;
//	int length;
//public:
//	String();
//	String(string _s);
//	~String();
//	string StrReplace(string s1,string s2,string s3, int pos);
//};
//
//#endif